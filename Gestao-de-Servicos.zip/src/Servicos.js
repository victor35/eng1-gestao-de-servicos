import React from 'react';

import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';


class Servicos extends React.Component  {

  render(){
    return(

      <div>
        <p> Servicos!!!!!!! </p>
      </div>
    )
  }

}


export default Servicos;