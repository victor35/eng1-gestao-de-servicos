import React from 'react';

import './App.css';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

class App extends React.Component  {

    login = {
      email:'victor',
      senha:'123'
    }

 render(){
    return (
      <div className="App">
        <div className="p-text-center">Gestão de Serviços</div>
        <br/> <br/>
        <label>Email:</label>
        <InputText value={this.login.email} onChange={(e) => this.setState({email: e.target.value})} />
        <br/> <br/>
        <label>Senha:</label>
        <InputText value={this.login.senha} onChange={(e) => this.setState({senha: e.target.value})} />

         <br/> <br/>

       <Button label="Entrar" onClick={this.goToPage}/>

      </div>
    );
  }
}

export default App;
